Passport Photo Studio Pro (v5.1 Fix - MediaPipe AI BG Removal)
=================================================================

Fixed & Updated Features:
1. Real-Time MediaPipe Selfie Segmentation: Person ko photo se alag (cutout) karta hai taaki background bina kisi error ke instantly change ho sake.
2. Custom Color Picker: Ab aap kisi bhi custom background color ko choose kar sakte hain.
3. Vignette (Edge Shadow): Smooth dark corner effect active rehta hai.
4. Canvas Layer Composite Fix: Subject aur background layering ko pure HTML5 Canvas ke dwara smooth kar diya gaya hai.

How to Run:
1. Extract ZIP file.
2. Open `index.html` in Google Chrome or any modern browser (Internet/WiFi connection active rakhein taaki MediaPipe AI models load ho sakein).


V5 Contrast Depth Update:
- Added a separate Contrast Depth slider (0-100) in Adjustments.
- Uses local luminance contrast to enhance facial/detail depth.
- Works independently from the existing global Contrast slider.
- Reset returns Contrast Depth to 0.


Dedicated Depth Tool Update:
- Added a separate Depth slider from -100 to +100.
- Positive values add dimensional facial micro-contrast.
- Negative values soften/reduce the depth effect.
- Existing Contrast and Contrast Depth controls remain separate.


4x6 8 Photos Print Update:
- Added Download 4x6 Sheet (8 Photos).
- Sheet is 4x6 inches at 300 DPI (1200x1800 px).
- Places 8 passport photos in a 2-column x 4-row layout.
- Uses the currently edited/rendered photo so all existing adjustments are preserved.


Reference-style 4x6 Cut Lines Update:
- 4x6 inch landscape sheet at 300 DPI (1800x1200 px).
- 8 passport photos arranged 4 across x 2 down.
- Dashed cutting guides are placed around/through the photo gaps.
- Corner crop marks and scissor marks are included.
- Existing photo edits are preserved in all 8 copies.


Manual Crop → Background Remove Workflow:
- After photo upload, Manual Crop mode opens automatically.
- User can move and resize the crop box using the mouse.
- AI background removal does not start during upload.
- Clicking Apply Crop & Remove BG first creates the high-resolution crop, then starts AI background removal.
- Existing editing and 4x6/8-photo print features remain available after cropping.
